import { useEffect, useState } from "react";
import API from "../../api/axios";
import "./Dashboard.css";

import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

import { Pie, Bar } from "react-chartjs-2";

import {
  FiUsers,
  FiCheckCircle,
  FiClock,
  FiAlertTriangle,
  FiRefreshCw,
  FiActivity,
  FiTrendingUp,
  FiBarChart2,
  FiShield,
  FiLayers,
  FiCalendar,
} from "react-icons/fi";

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

function Dashboard() {
  const [stats, setStats] = useState({});
  const [recentCustomers, setRecentCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    loadDashboard();

    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const loadDashboard = async () => {
    try {
      setLoading(true);
      setError("");

      const res = await API.get("/api/dashboard");

      const data = res.data?.data || {};

      setStats(data.stats || {});
      setRecentCustomers(data.recentCustomers || []);
    } catch (err) {
      console.error(err);
      setError("Unable to load dashboard.");
    } finally {
      setLoading(false);
    }
  };

  const pieData = {
    labels: ["Active", "Pending", "Resolved", "Closed"],
    datasets: [
      {
        data: [
          stats.activeCustomers || 0,
          stats.pendingCustomers || 0,
          stats.resolvedCustomers || 0,
          stats.closedCustomers || 0,
        ],
        backgroundColor: [
          "#22c55e",
          "#f59e0b",
          "#3b82f6",
          "#ef4444",
        ],
        borderWidth: 0,
      },
    ],
  };

  const barData = {
    labels: ["Low", "Medium", "High"],
    datasets: [
      {
        label: "Priority",
        data: [
          stats.lowPriority || 0,
          stats.mediumPriority || 0,
          stats.highPriority || 0,
        ],
        backgroundColor: [
          "#22c55e",
          "#f59e0b",
          "#ef4444",
        ],
        borderRadius: 8,
      },
    ],
  };

  const cards = [
    {
      title: "Total Customers",
      value: stats.totalCustomers || 0,
      icon: <FiUsers />,
      color: "#3b82f6",
    },
    {
      title: "Active",
      value: stats.activeCustomers || 0,
      icon: <FiCheckCircle />,
      color: "#22c55e",
    },
    {
      title: "Pending",
      value: stats.pendingCustomers || 0,
      icon: <FiClock />,
      color: "#f59e0b",
    },
    {
      title: "Resolved",
      value: stats.resolvedCustomers || 0,
      icon: <FiActivity />,
      color: "#06b6d4",
    },
    {
      title: "Closed",
      value: stats.closedCustomers || 0,
      icon: <FiShield />,
      color: "#ef4444",
    },
    {
      title: "Low Priority",
      value: stats.lowPriority || 0,
      icon: <FiTrendingUp />,
      color: "#22c55e",
    },
    {
      title: "Medium Priority",
      value: stats.mediumPriority || 0,
      icon: <FiLayers />,
      color: "#f59e0b",
    },
    {
      title: "High Priority",
      value: stats.highPriority || 0,
      icon: <FiAlertTriangle />,
      color: "#ef4444",
    },
  ];

  if (loading) {
    return (
      <div className="dashboard loading-dashboard">
        <div className="loader"></div>
        <h2>Loading Dashboard...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard loading-dashboard">
        <h2>{error}</h2>

        <button
          className="refresh-btn"
          onClick={loadDashboard}
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="dashboard">

      {/* ================= HEADER ================= */}

      <div className="dashboard-header">

        <div>

          <h1>Customer Care Dashboard</h1>

          <p>
            Monitor customer requests, priorities and service
            performance in one place.
          </p>

        </div>

        <div className="header-actions">

          <div className="date-box">

            <FiCalendar />

            <span>
              {currentTime.toLocaleDateString()}
            </span>

          </div>

          <div className="date-box">

            <FiClock />

            <span>
              {currentTime.toLocaleTimeString()}
            </span>

          </div>

          <button
            className="refresh-btn"
            onClick={loadDashboard}
          >
            <FiRefreshCw />
            Refresh
          </button>

        </div>

      </div>

      {/* Statistics Cards */}

      <div className="stats-grid">

        {cards.map((card, index) => (

          <div
            className="stat-card"
            key={index}
          >

            <div
              className="icon-box"
              style={{
                background: card.color,
              }}
            >
              {card.icon}
            </div>

            <div className="stat-info">

              <h2>{card.value}</h2>

              <p>{card.title}</p>

            </div>

          </div>

        ))}

      </div>
            {/* ================= CHARTS SECTION ================= */}

      <div className="dashboard-grid">

        {/* Status Chart */}

        <div className="chart-card">

          <div className="card-header">

            <h3>
              <FiBarChart2 />
              Customer Status
            </h3>

            <span>Overview</span>

          </div>

          <div className="chart-wrapper">

            <Pie
              data={pieData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: "bottom",
                    labels: {
                      color: "#cbd5e1",
                      padding: 20,
                      font: {
                        size: 13,
                      },
                    },
                  },
                },
              }}
            />

          </div>

        </div>

        {/* Priority Chart */}

        <div className="chart-card">

          <div className="card-header">

            <h3>
              <FiTrendingUp />
              Priority Distribution
            </h3>

            <span>Current</span>

          </div>

          <div className="chart-wrapper">

            <Bar
              data={barData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false,
                  },
                },
                scales: {
                  x: {
                    ticks: {
                      color: "#cbd5e1",
                    },
                    grid: {
                      display: false,
                    },
                  },
                  y: {
                    beginAtZero: true,
                    ticks: {
                      color: "#cbd5e1",
                    },
                    grid: {
                      color: "#334155",
                    },
                  },
                },
              }}
            />

          </div>

        </div>

      </div>

      {/* ================= STATUS SUMMARY ================= */}

      <div className="summary-grid">

        <div className="summary-card">

          <h3>Customer Status Overview</h3>

          <div className="progress-item">

            <div className="progress-top">
              <span>Active Customers</span>
              <span>{stats.activeCustomers || 0}</span>
            </div>

            <div className="progress">
              <div
                className="progress-fill active-fill"
                style={{
                  width: `${
                    stats.totalCustomers
                      ? (stats.activeCustomers /
                          stats.totalCustomers) *
                        100
                      : 0
                  }%`,
                }}
              ></div>
            </div>

          </div>

          <div className="progress-item">

            <div className="progress-top">
              <span>Pending Customers</span>
              <span>{stats.pendingCustomers || 0}</span>
            </div>

            <div className="progress">
              <div
                className="progress-fill pending-fill"
                style={{
                  width: `${
                    stats.totalCustomers
                      ? (stats.pendingCustomers /
                          stats.totalCustomers) *
                        100
                      : 0
                  }%`,
                }}
              ></div>
            </div>

          </div>

          <div className="progress-item">

            <div className="progress-top">
              <span>Resolved Customers</span>
              <span>{stats.resolvedCustomers || 0}</span>
            </div>

            <div className="progress">
              <div
                className="progress-fill resolved-fill"
                style={{
                  width: `${
                    stats.totalCustomers
                      ? (stats.resolvedCustomers /
                          stats.totalCustomers) *
                        100
                      : 0
                  }%`,
                }}
              ></div>
            </div>

          </div>

          <div className="progress-item">

            <div className="progress-top">
              <span>Closed Customers</span>
              <span>{stats.closedCustomers || 0}</span>
            </div>

            <div className="progress">
              <div
                className="progress-fill closed-fill"
                style={{
                  width: `${
                    stats.totalCustomers
                      ? (stats.closedCustomers /
                          stats.totalCustomers) *
                        100
                      : 0
                  }%`,
                }}
              ></div>
            </div>

          </div>

        </div>

        {/* Priority Summary */}

        <div className="summary-card">

          <h3>Priority Summary</h3>

          <div className="priority-box low-box">

            <h2>{stats.lowPriority || 0}</h2>

            <p>Low Priority</p>

          </div>

          <div className="priority-box medium-box">

            <h2>{stats.mediumPriority || 0}</h2>

            <p>Medium Priority</p>

          </div>

          <div className="priority-box high-box">

            <h2>{stats.highPriority || 0}</h2>

            <p>High Priority</p>

          </div>

        </div>

      </div>
            {/* ===================== BOTTOM SECTION ===================== */}

      <div className="bottom-grid">

        {/* ================= RECENT CUSTOMERS ================= */}

        <div className="recent-card">

          <div className="card-header">

            <h3>
              <FiUsers />
              Recent Customers
            </h3>

            <span>
              {recentCustomers.length} Records
            </span>

          </div>

          {recentCustomers.length === 0 ? (

            <div className="empty-state">

              <FiUsers size={45} />

              <h4>No Customers Found</h4>

              <p>
                Customers will appear here after they are added.
              </p>

            </div>

          ) : (

            <table className="customer-table">

              <thead>

                <tr>

                  <th>Name</th>

                  <th>Company</th>

                  <th>Status</th>

                  <th>Priority</th>

                </tr>

              </thead>

              <tbody>

                {recentCustomers.map((customer) => (

                  <tr key={customer._id}>

                    <td>

                      <div className="customer-name">

                        <div className="avatar">

                          {customer.fullName
                            ? customer.fullName.charAt(0).toUpperCase()
                            : "U"}

                        </div>

                        <span>{customer.fullName}</span>

                      </div>

                    </td>

                    <td>{customer.company}</td>

                    <td>

                      <span
                        className={`badge status-${(
                          customer.status || ""
                        ).toLowerCase()}`}
                      >
                        {customer.status}
                      </span>

                    </td>

                    <td>

                      <span
                        className={`badge priority-${(
                          customer.priority || ""
                        ).toLowerCase()}`}
                      >
                        {customer.priority}
                      </span>

                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          )}

        </div>

        {/* ================= SIDEBAR ================= */}

        <div className="side-panel">

          {/* Quick Actions */}

          <div className="quick-card">

            <h3>Quick Actions</h3>

            <button>
              <FiUsers />
              Add Customer
            </button>

            <button>
              <FiActivity />
              View Customers
            </button>

            <button onClick={loadDashboard}>
              <FiRefreshCw />
              Refresh Dashboard
            </button>

          </div>

          {/* Insights */}

          <div className="insight-card">

            <h3>Dashboard Insights</h3>

            <div className="insight-item">

              <span>Total Customers</span>

              <strong>
                {stats.totalCustomers || 0}
              </strong>

            </div>

            <div className="insight-item">

              <span>Open Cases</span>

              <strong>
                {(stats.activeCustomers || 0) +
                  (stats.pendingCustomers || 0)}
              </strong>

            </div>

            <div className="insight-item">

              <span>Completed Cases</span>

              <strong>
                {(stats.resolvedCustomers || 0) +
                  (stats.closedCustomers || 0)}
              </strong>

            </div>

            <div className="insight-item">

              <span>High Priority</span>

              <strong>
                {stats.highPriority || 0}
              </strong>

            </div>

          </div>

          {/* Recent Activity */}

          <div className="activity-card">

            <h3>Recent Activity</h3>

            {recentCustomers.length === 0 ? (

              <p className="no-activity">
                No recent activity available.
              </p>

            ) : (

              recentCustomers.map((customer) => (

                <div
                  className="activity-item"
                  key={`activity-${customer._id}`}
                >

                  <div className="activity-dot"></div>

                  <div>

                    <strong>
                      {customer.fullName}
                    </strong>

                    <p>
                      {customer.company}
                    </p>

                    <small>
                      Status: {customer.status}
                    </small>

                  </div>

                </div>

              ))

            )}

          </div>

        </div>

      </div>
            
      {/* ================= FOOTER ================= */}

      <footer className="dashboard-footer">

        <div>

          <h3>Customer Care Registry</h3>

          <p>
            Dashboard overview for monitoring customer requests,
            priorities and service status.
          </p>

        </div>

        <div className="footer-stats">

          <div>

            <span>Total</span>

            <strong>{stats.totalCustomers || 0}</strong>

          </div>

          <div>

            <span>Resolved</span>

            <strong>{stats.resolvedCustomers || 0}</strong>

          </div>

          <div>

            <span>Closed</span>

            <strong>{stats.closedCustomers || 0}</strong>

          </div>

        </div>

      </footer>

    </div>
  );
}

export default Dashboard;